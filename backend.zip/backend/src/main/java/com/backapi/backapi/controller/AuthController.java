package com.backapi.backapi.controller;

import com.backapi.backapi.dto.request.LoginRequest;
import com.backapi.backapi.dto.request.RegisterRequest;
import com.backapi.backapi.dto.response.AuthResponse;
import com.backapi.backapi.service.AuthService;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final AuthService authService;

    private void addRefreshTokenCookie(HttpServletResponse response, String refreshToken) {
        Cookie cookie = new Cookie("refreshToken", refreshToken);
        cookie.setHttpOnly(true);
        cookie.setSecure(true); // только HTTPS в продакшене
        cookie.setPath("/");
        cookie.setMaxAge(7 * 24 * 60 * 60); // 7 дней
        cookie.setAttribute("SameSite", "Strict");
        response.addCookie(cookie);
    }

    @PostMapping("/register")
    public ResponseEntity<AuthResponse> register(
            @Valid @RequestBody RegisterRequest request,
            HttpServletResponse response) {

        AuthResponse auth = authService.register(request);
        addRefreshTokenCookie(response, auth.getRefreshToken());
        auth.setRefreshToken(null); // не возвращаем в JSON
        return ResponseEntity.ok(auth);
    }

    @PostMapping("/login")
    public ResponseEntity<AuthResponse> login(
            @Valid @RequestBody LoginRequest request,
            HttpServletResponse response) {

        AuthResponse auth = authService.login(request);
        addRefreshTokenCookie(response, auth.getRefreshToken());
        auth.setRefreshToken(null);
        return ResponseEntity.ok(auth);
    }

    // ─── НОВЫЙ ВАРИАНТ /refresh ─────────────────────────────────────
    @PostMapping("/refresh")
    public ResponseEntity<AuthResponse> refresh(
            @CookieValue(name = "refreshToken", required = false) String refreshToken,
            HttpServletResponse response) {

        log.info("=== REFRESH REQUEST STARTED ===");
        log.info("Refresh token from cookie: {}",
                refreshToken != null ? "PRESENT (length: " + refreshToken.length() + ")" : "NULL or missing");

        if (refreshToken == null || refreshToken.isBlank()) {
            log.warn("Refresh token is missing from both cookie and header");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }

        try {
            log.info("Calling authService.refreshToken() with token length: {}", refreshToken.length());

            AuthResponse auth = authService.refreshToken(refreshToken);

            log.info("Service returned successfully. New access token length: {}",
                    auth.getAccessToken() != null ? auth.getAccessToken().length() : 0);

            addRefreshTokenCookie(response, auth.getRefreshToken());
            log.info("New refresh token cookie has been set");

            auth.setRefreshToken(null);
            log.info("=== REFRESH REQUEST COMPLETED SUCCESSFULLY ===");

            return ResponseEntity.ok(auth);

        } catch (Exception e) {
            log.error("=== REFRESH REQUEST FAILED ===", e);
            log.error("Error message: {}", e.getMessage());
            log.error("Error type: {}", e.getClass().getSimpleName());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }
}